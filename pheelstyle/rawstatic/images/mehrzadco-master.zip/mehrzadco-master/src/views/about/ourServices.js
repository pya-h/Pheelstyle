const ourServices = [
    {
        id: 1,
        title: 'نظارت',
        details: [
            {text: "توضیحات"}
        ],
        positon: 'left',
        style: 'normal'
    },
    {
        id: 2,
        title: 'اجرا',
        details: [
            {text: "توضیحات"},
        ],
        positon: 'right',
        style: 'normal'
    },
    {
        id: 3,
        title: 'خرید و فروش',
        details: [
            {text: "توضیحات"}
        ],
        positon: 'left'
    },
    {
        id: 4,
        title: 'طراحی',
        details: [
            {text: "توضیحات"}
        ],
        positon: 'right'
    },
    {
        id: 5,
        title: 'نقشه کشی',
        details: [
            {text: "توضیحات"}
        ],
        positon: 'left'
    },
];
export default ourServices;